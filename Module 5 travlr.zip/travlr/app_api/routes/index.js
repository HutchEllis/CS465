const express = require('express');
const router = express.Router();

// Import controllers
const tripsController = require('../controllers/trips');

// Define route for trips endpoint
router
  .route('/trips')
  .get(tripsController.tripsList); // GET method for tripsList

// GET Method for tripsFindByCode
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode);

module.exports = router;
