import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private trips: any[] = []; // Local storage for trips

  constructor() { }

  // Mock implementation of the addTrip method
  addTrip(trip: any): Observable<any> {
    this.trips.push(trip);
    return of(trip); // Simulate an observable response
  }

  // Optional: Method to retrieve all trips
  getTrips(): Observable<any[]> {
    return of(this.trips);
  }
}
