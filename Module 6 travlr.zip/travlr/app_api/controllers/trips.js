const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');

// GET: /trips - lists all the trips
const tripsList = async (req, res) => {
    try {
        const q = await Model.find().exec(); // Return all trips

        if (!q || q.length === 0) { // Database returned no data
            return res.status(404).json({ "message": "No trips found" });
        } else { // Return resulting trip list
            return res.status(200).json(q);
        }
    } catch (err) {
        return res.status(500).json({ "message": "Server error", "error": err });
    }
};

// GET: /trips/:tripCode - finds a trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const q = await Model.findOne({ 'code': req.params.tripCode }).exec(); // Return single record

        if (!q) { // Database returned no data
            return res.status(404).json({ "message": "Trip not found" });
        } else { // Return resulting trip
            return res.status(200).json(q);
        }
    } catch (err) {
        return res.status(500).json({ "message": "Server error", "error": err });
    }
};

// POST: /trips - create a new trip
const tripsAddTrip = async (req, res) => {
    try {
        const newTrip = new Model({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description,
        });

        const savedTrip = await newTrip.save();
        return res.status(201).json(savedTrip);
    } catch (err) {
        return res.status(400).json({ "message": "Failed to create trip", "error": err });
    }
};

// PUT: /trips/:tripCode - update an existing trip
const tripsUpdateTrip = async (req, res) => {
    try {
        const updatedTrip = await Model.findOneAndUpdate(
            { 'code': req.params.tripCode },
            {
                code: req.body.code,
                name: req.body.name,
                length: req.body.length,
                start: req.body.start,
                resort: req.body.resort,
                perPerson: req.body.perPerson,
                image: req.body.image,
                description: req.body.description
            },
            { new: true } // Return the updated document
        ).exec();

        if (!updatedTrip) { // Database returned no data
            return res.status(404).json({ "message": "Trip not found" });
        } else { // Return resulting updated trip
            return res.status(200).json(updatedTrip);
        }
    } catch (err) {
        return res.status(400).json({ "message": "Failed to update trip", "error": err });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};
