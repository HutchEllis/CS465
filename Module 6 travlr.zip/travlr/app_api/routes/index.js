const express = require('express');
const router = express.Router();

// Import controllers
const tripsController = require('../controllers/trips');

// Define route for trips endpoint
router
  .route('/trips')
  .get(tripsController.tripsList) // GET method for tripsList
  .post(tripsController.tripsAddTrip); // POST method adds a trip

// GET Method
// PUT Method
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(tripsController.tripsUpdateTrip);

module.exports = router;
