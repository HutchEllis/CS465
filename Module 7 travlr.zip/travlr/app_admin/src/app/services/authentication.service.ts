import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/AuthResponse';
import { TripDataService } from '../services/trip-data.service';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators'; // Ensure you import tap

@Injectable({
    providedIn: 'root'
})
export class AuthenticationService {
    authResp: AuthResponse = new AuthResponse();

    constructor(
        @Inject(BROWSER_STORAGE) private storage: Storage,
        private tripDataService: TripDataService
    ) { }

    public getToken(): string {
        return this.storage.getItem('travlr-token') || '';
    }

    public saveToken(token: string): void {
        this.storage.setItem('travlr-token', token);
    }

    public logout(): void {
        this.storage.removeItem('travlr-token');
    }

    public isLoggedIn(): boolean {
        const token = this.getToken();
        if (token) {
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.exp > (Date.now() / 1000);
        } else {
            return false;
        }
    }

    public getCurrentUser(): User {
        const token = this.getToken();
        const { email, name } = JSON.parse(atob(token.split('.')[1]));
        return { email, name } as User;
    }

    public login(user: User, passwd: string): Observable<AuthResponse> {
        return this.tripDataService.login(user, passwd).pipe(
            tap((response: AuthResponse) => this.saveToken(response.token))
        );
    }

    public register(user: User, passwd: string): Observable<AuthResponse> {
        return this.tripDataService.register(user, passwd).pipe(
            tap((response: AuthResponse) => this.saveToken(response.token))
        );
    }
}
