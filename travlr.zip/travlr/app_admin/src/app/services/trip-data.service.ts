import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/AuthResponse';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private baseUrl = 'http://localhost:3000/api'; // Base URL for the backend API
  private tripsUrl = `${this.baseUrl}/trips`; // URL for trips endpoint

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  // Get all trips
  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.tripsUrl);
  }

  // Add a new trip
  addTrip(trip: Trip): Observable<Trip> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getToken()}`
    });
    return this.http.post<Trip>(this.tripsUrl, trip, { headers });
  }

  // Get a specific trip by code
  getTrip(code: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.tripsUrl}/${code}`);
  }

  // Update an existing trip
  updateTrip(trip: Trip): Observable<Trip> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getToken()}`
    });
    return this.http.put<Trip>(`${this.tripsUrl}/${trip.code}`, trip, { headers });
  }

  // Login user
  login(user: User, password: string): Observable<AuthResponse> {
    const formData = { email: user.email, password: password };
    return this.http.post<AuthResponse>(`${this.baseUrl}/login`, formData);
  }

  // Register user
  register(user: User, password: string): Observable<AuthResponse> {
    const formData = { name: user.name, email: user.email, password: password };
    return this.http.post<AuthResponse>(`${this.baseUrl}/register`, formData);
  }

  // Helper method to get the JWT token from local storage
  private getToken(): string {
    return this.storage.getItem('travlr-token') || '';
  }
}
