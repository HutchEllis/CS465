const mongoose = require('mongoose');
const User = require('../models/user');
const passport = require('passport');

const login = (req, res) => {
    console.log('Login request received with body:', req.body);

    if (!req.body.email || !req.body.password) {
        return res.status(400).json({ message: "All fields required" });
    }

    passport.authenticate('local', (err, user, info) => {
        if (err) {
            console.error('Authentication error:', err);
            return res.status(500).json({ message: "Internal server error during authentication" });
        }

        if (user) {
            console.log('User authenticated:', user);
            const token = user.generateJWT();
            return res.status(200).json({ token });
        } else {
            console.warn('Authentication failed:', info);
            return res.status(401).json(info);
        }
    })(req, res);
};

const register = async (req, res) => {
    console.log('Register request received with body:', req.body);

    if (!req.body.name || !req.body.email || !req.body.password) {
        return res.status(400).json({ message: "All fields required" });
    }

    const user = new User({
        name: req.body.name,
        email: req.body.email,
        password: ''
    });

    user.setPassword(req.body.password);

    try {
        const q = await user.save();
        console.log('User registered:', user);
        const token = user.generateJWT();
        return res.status(200).json({ token });
    } catch (err) {
        console.error('Registration error:', err);
        return res.status(500).json({ message: "Internal server error during registration" });
    }
};

module.exports = {
    register,
    login
};
